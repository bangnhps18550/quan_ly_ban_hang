/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo6;

public class TestMyThread {
    public static void main(String[] args) {
        
        MyThread t1 = new MyThread();
        t1.setName("tiểu trình 1");
        t1.start();
        System.out.println(t1);
        
        
        MyThread t2 = new MyThread();
        t2.setName("tiểu trình 2");
        t2.start();
        System.out.println(t2);
        
    }
    
}
